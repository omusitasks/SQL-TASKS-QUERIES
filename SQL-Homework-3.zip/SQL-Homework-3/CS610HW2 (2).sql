create database homework2;

\c homework2

create domain empidtype as integer check (value >=100 and value <=99999);

create domain deptidtype as char(6);

create domain emailchars as varchar(25);

create domain namechars as varchar(15);

create domain gendertype as char(1) check(value in ('m', 'f'));

create domain ratingtype as char(2) check(value in('A', 'B', 'C', 'D'));

create domain creditslimit as integer check (value >=0 and value <=128);

create table employees(empid empidtype primary key, empname namechars,email emailchars, gender gendertype, rating ratingtype,
years real, credits creditslimit, age integer);

create table departments(deptid deptidtype not null primary key, deptname namechars not null, building integer not null, empcount integer, deptemail emailchars);

create table members(deptid deptidtype not null, empid empidtype not null, datejoined date not null, primary key(deptid, empid, datejoined), constraint fk1 foreign key(empid) references employees(empid), foreign key (deptid) references departments(deptid));

insert into employees (empid, empname, email, gender, rating, years, credits, age) values 
(100,'Dave','dave@acme.edu','m','A',10.1,24,30),
(101,'Betty','betty@acme.edu','f','B',5,100,33),
(102,'Jane','jane@acme.edu','f','D',4.4,45,22),
(103,'Ted','ted@acme.edu','m','D',12.9,12,36),
(104,'George','george@acme.edu','m','A',8.6,72,37),
(105,'Sally','sally@acme.edu','f','B',2.2,56,29),
(106,'Sam','Sam@acme.edu','m','D',0.8,81,40),
(107,'Fred','fred@acme.edu','m','D',19,12,42),
(108,'Susan','susan@acme.edu','f','A',18.3,32,33),
(109,'Tom','tom@acme.edu','m','B',15.2,65,55),
(110,'Beth','beth@acme.edu','f','D',7.6,48,36),
(111,'Harry','harry@acme.edu','m','D',3.3,48,51);

insert into departments (deptid, deptname, building, empcount, deptemail) values
('D00000','HR',321,null,'betty@acme.edu'),
('D00001','R&D',301,null,'tom@acme.edu'),
('D00002','Accounting',101,null,'susan@acme.edu'),
('D00003','Finance',0,null,null),
('D00004','Sales',400,null,'betty@acme.edu'),
('D00005','Marketing',400,Null,'fred@acme.edu');

insert into members (deptid, empid, datejoined)
values
('D00000',101,'2013-05-12'),
('D00001',109,'2014-10-11'),
('D00002',105,'2014-11-12'),
('D00004',101,'2013-06-10'),
('D00000',102,'2014-11-21'),
('D00003',103,'2013-12-01'),
('D00000',104,'2014-07-28'),
('D00000',105,'2013-10-22'),
('D00000',106,'2014-10-29'),
('D00000',107,'2014-09-12'),
('D00000',108,'2013-09-01'),
('D00000',109,'2015-01-01'),
('D00000',110,'2013-03-31'),
('D00001',105,'2014-11-21'),
('D00001',107,'2014-09-12'),
('D00001',108,'2013-09-01'),
('D00002',102,'2014-11-21'),
('D00002',103,'2013-12-01'),
('D00002',104,'2014-07-28'),
('D00002',101,'2013-10-22'),
('D00002',106,'2014-10-29'),
('D00002',107,'2014-09-12'),
('D00002',108,'2013-09-01'),
('D00002',109,'2015-01-01'),
('D00002',110,'2013-03-31'),
('D00004',102,'2014-11-21'),
('D00004',104,'2014-07-28'),
('D00004',105,'2014-10-29'),
('D00004',108,'2013-09-01'),
('D00004',109,'2015-01-01'),
('D00004',110,'2013-03-31');